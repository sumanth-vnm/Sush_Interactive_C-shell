#include "headers.h"

void bg(char *d,char **arr,int comm){
    system("bg");
}